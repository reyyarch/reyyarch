#!/bin/bash

CURRENT_WALL="$HOME/.cache/current_wallpaper"

# Start swww
swww-daemon &
sleep 1.5

# Restore wallpaper terakhir
if [ -f "$CURRENT_WALL" ]; then
    WALLPAPER=$(cat "$CURRENT_WALL")
    
    # Set wallpaper
    swww img "$WALLPAPER" \
        --transition-type fade \
        --transition-duration 1
    
    # Update hyprlock config - PATH YANG BENAR
    sed -i "s|path = .*|path = $WALLPAPER|" ~/.config/hypr/hyprlock/hyprlock.conf
fi
```

---

## 4. Struktur Direktori:
```
~/.config/hypr/
├── hyprland.conf
├── hyprlock/
│   ├── hyprlock.conf     # File config kamu
│   └── colors.conf       # File colors yang di-source
└── scripts/
