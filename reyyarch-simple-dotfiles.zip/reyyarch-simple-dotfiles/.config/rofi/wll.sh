#!/bin/bash

WALLDIR="$HOME/.config/rofi/wallpapers"
TOGGLE_FILE="$HOME/.cache/bubble_toggle"
CURRENT_WALL="$HOME/.cache/current_wallpaper"
HYPRLOCK_WALL="$HOME/.cache/hyprlock_wallpaper.png"

# Start swww
if ! pgrep -x swww-daemon > /dev/null; then
    swww-daemon &
    sleep 2
fi

# Rofi
CHOICE=$(cd "$WALLDIR" && ls -1 *.{png,jpg,jpeg,webp} 2>/dev/null | sort -V | while read img; do
    echo -en "$img\0icon\x1f$WALLDIR/$img\n"
done | rofi -dmenu -show-icons -i -p "󰸉  Wallpaper" -theme ~/.config/rofi/wallpaper.rasi)

[ -z "$CHOICE" ] && exit 0

# Full path wallpaper
WALLPAPER_PATH="$WALLDIR/$CHOICE"

# Simpan path
echo "$WALLPAPER_PATH" > "$CURRENT_WALL"

# Update symlink untuk hyprlock
ln -sf "$WALLPAPER_PATH" "$HYPRLOCK_WALL"

# RUN WALLUST - Generate colors
wallust run "$WALLPAPER_PATH"

# Reload waybar dengan colors baru
killall waybar
waybar &

# Reload hyprland colors
hyprctl reload

# Baca toggle
[ -f "$TOGGLE_FILE" ] && TOGGLE=$(cat "$TOGGLE_FILE") || TOGGLE=0

if [ "$TOGGLE" -eq 0 ]; then
    swww img "$WALLPAPER_PATH" \
        --transition-type grow \
        --transition-pos center \
        --transition-duration 1.5 \
        --transition-fps 60
    echo 1 > "$TOGGLE_FILE"
else
    swww img "$WALLPAPER_PATH" \
        --transition-type outer \
        --transition-pos center \
        --transition-duration 1.5 \
        --transition-fps 60
    echo 0 > "$TOGGLE_FILE"
fi

# Kill hyprlock agar reload
pkill hyprlock 2>/dev/null